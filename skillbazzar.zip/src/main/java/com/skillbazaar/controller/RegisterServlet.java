package com.skillbazaar.controller;

import com.skillbazaar.dao.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get form input values from register.jsp
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try (Connection con = DBConnection.getConnection()) {
            String sql = "INSERT INTO student_registration (name, email, password) VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, password);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                request.getSession().setAttribute("message", "Registration successful!");
                request.getSession().setAttribute("status", "success");
            } else {
                request.getSession().setAttribute("message", "Registration failed.");
                request.getSession().setAttribute("status", "error");
            }

        } catch (SQLIntegrityConstraintViolationException e) {
            request.getSession().setAttribute("message", "Email already exists.");
            request.getSession().setAttribute("status", "error");
        } catch (Exception e) {
            e.printStackTrace(); // For server logs
            request.getSession().setAttribute("message", "Something went wrong: " + e.getMessage());
            e.printStackTrace();
            request.getSession().setAttribute("status", "error");
        }

        response.sendRedirect("register.jsp");
    }
}
