package com.skillbazaar.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.skillbazaar.entities.Instructor;

@WebServlet("/GetInstructorsServlet")
public class GetInstructorsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database credentials
    private static final String DB_URL = "jdbc:mysql://localhost:3306/skillbazaar";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "1234";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Instructor> instructorList = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                 PreparedStatement ps = con.prepareStatement("SELECT id, name FROM instructor_login");
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    Instructor instructor = new Instructor();
                    instructor.setId(rs.getInt("id"));
                    instructor.setName(rs.getString("name"));
                    instructorList.add(instructor);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("instructors", instructorList);
        request.getRequestDispatcher("instructors.jsp").forward(request, response);
    }
}
