package com.skillbazaar.entities;

public class CourseModel {
    private int id;
    private String title;
    private String description;
    private int price;
    private String link; // ✅ Added link field
    private String image;

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getLink() {  // ✅ Added this method
        return link;
    }

    public void setLink(String link) {  // ✅ Added this method
        this.link = link;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
